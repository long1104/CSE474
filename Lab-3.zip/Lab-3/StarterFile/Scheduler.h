
#ifndef SCHEDULER_H_
#define SCHEDULER_H_
#include "TaskControlBlock.h"



extern TCB *tasksPtr;
void Scheduler();

#endif
